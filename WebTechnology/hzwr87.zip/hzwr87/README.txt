Code to summarise a text document, based on link provided in lecture slides

https://technowiki.wordpress.com/2011/08/27/latent-semantic-analysis-lsa-tutorial/

text files supplied on the command line, run with python webTechnology.py filename.txt

Several text files are provided containing book titles related to a specified area, taken from amazon searches